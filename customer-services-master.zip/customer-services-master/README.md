A task on creating spring boot application illustrating MVC architecture, ORM framework and Mockito framework
